export interface UserGroup {

  id: number;
  groupName: string;
  description: string;
  createdDate: string;
  updatedDate: string;

}
