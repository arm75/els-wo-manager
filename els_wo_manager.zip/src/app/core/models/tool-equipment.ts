export interface ToolEquipment {
  id: number;
  entityName: string;
  description: string;
  pricePerDay: number;
  createdDate: string;
  updatedDate: string;
}
