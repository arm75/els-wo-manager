export interface Labor {
  id: number;
  entityName: string;
  description: string;
  ratePerHour: number;
  createdDate: string;
  updatedDate: string;
}
