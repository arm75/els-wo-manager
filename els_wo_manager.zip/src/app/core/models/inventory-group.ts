export interface InventoryGroup {
  id: number;
  entityName: string;
  description: string;
  createdDate: string;
  updatedDate: string;
}
