export interface CustomHttpResponse {
  code: number;
  status: string;
  reason: string;
  message: string;
  timestamp: string;
}

