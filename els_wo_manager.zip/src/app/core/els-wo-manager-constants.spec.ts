import { ElsWoManagerConstants } from './els-wo-manager-constants';

describe('ElsWoManagerConstants', () => {
  it('should create an instance', () => {
    expect(new ElsWoManagerConstants()).toBeTruthy();
  });
});
