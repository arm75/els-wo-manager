import { GlobalFormErrorStateMatcher } from './global-form-error-state-matcher';

describe('GlobalFormErrorStateMatcher', () => {
  it('should create an instance', () => {
    expect(new GlobalFormErrorStateMatcher()).toBeTruthy();
  });
});
