import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-order-edit-tab-form',
  templateUrl: './work-order-edit-tab-form.component.html',
  styleUrls: ['./work-order-edit-tab-form.component.css']
})
export class WorkOrderEditTabFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
