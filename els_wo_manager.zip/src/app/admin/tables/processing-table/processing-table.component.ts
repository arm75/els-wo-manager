import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-processing-table',
  templateUrl: './processing-table.component.html',
  styleUrls: ['./processing-table.component.css']
})
export class ProcessingTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
