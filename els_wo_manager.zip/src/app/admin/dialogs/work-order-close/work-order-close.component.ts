import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-order-close',
  templateUrl: './work-order-close.component.html',
  styleUrls: ['./work-order-close.component.css']
})
export class WorkOrderCloseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
