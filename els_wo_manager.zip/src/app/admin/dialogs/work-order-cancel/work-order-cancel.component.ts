import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-order-cancel',
  templateUrl: './work-order-cancel.component.html',
  styleUrls: ['./work-order-cancel.component.css']
})
export class WorkOrderCancelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
