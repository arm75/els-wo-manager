import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-order-retry',
  templateUrl: './work-order-retry.component.html',
  styleUrls: ['./work-order-retry.component.css']
})
export class WorkOrderRetryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
