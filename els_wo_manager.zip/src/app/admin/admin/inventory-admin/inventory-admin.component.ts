import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-admin',
  templateUrl: './inventory-admin.component.html',
  styleUrls: ['./inventory-admin.component.css']
})
export class InventoryAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
